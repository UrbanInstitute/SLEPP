
----------------------------------------------
Urban Institute SLEPP Database Public Release
Last Updated : 2014-08-13 11:43:47.603087
----------------------------------------------

This folder was generated from the most recent version of the Urban Institute SLEPP database. "plan_database.csv" contains the plan rules. The files in the "retirement penalty details" folder contain additional retirement penalty rates for plans. They are referred to in "plan_database.csv" under the "Additional Details on Early Retirement Penalties" column.
